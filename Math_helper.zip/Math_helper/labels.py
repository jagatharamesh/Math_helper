class Labels:
    def __init__(self, ):
        self.class_names = {0: "Algebra",1: "Number Theory",2: "Geometry",3: "Precalculus",4: "Counting & Probability"}


if __name__ == "__main__":
    labels=Labels()